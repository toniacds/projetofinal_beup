package com.beup;  // Definindo o pacote onde a classe está localizada. Pacotes ajudam a organizar o código.

import org.springframework.boot.SpringApplication;  // Importando a classe SpringApplication, responsável por iniciar a aplicação Spring Boot.
import org.springframework.boot.autoconfigure.SpringBootApplication;  // Importando a anotação @SpringBootApplication, que configura a aplicação automaticamente.

@SpringBootApplication  // A anotação @SpringBootApplication indica que esta é a classe principal da aplicação Spring Boot. Ela habilita várias configurações automáticas.
public class PrjBeUpSiteApplication {  // Definindo a classe principal da aplicação. O nome da classe pode ser alterado conforme a convenção do projeto.

    public static void main(String[] args) {  // O método main é o ponto de entrada da aplicação Java, onde o código começa a ser executado.
        
        SpringApplication.run(PrjBeUpSiteApplication.class, args);  // Chama o método run da classe SpringApplication para iniciar a aplicação Spring Boot.
        // O primeiro argumento é a própria classe (PrjBeUpSiteApplication.class), que contém a configuração da aplicação.
        // O segundo argumento (args) é utilizado para passar parâmetros da linha de comando para a aplicação, se necessário.
        
    }  // Fim do método main.

}  // Fim da classe principal.
