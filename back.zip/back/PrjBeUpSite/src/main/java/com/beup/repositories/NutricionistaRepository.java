package com.beup.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.beup.entities.Nutricionista;

public interface NutricionistaRepository extends JpaRepository<Nutricionista, Integer> {}


