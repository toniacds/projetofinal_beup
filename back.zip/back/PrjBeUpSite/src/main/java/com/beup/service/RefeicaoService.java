package com.beup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.beup.entities.Cardapio;
import com.beup.entities.Refeicao;
import com.beup.repositories.CardapioRepository;
import com.beup.repositories.RefeicaoRepository;

import jakarta.transaction.Transactional;

@Service
public class RefeicaoService {

	@Autowired
	private RefeicaoRepository refeicaoRepository;

	@Autowired
	private CardapioRepository cardapioRepository;

	// Listar todas as refeições
	public List<Refeicao> findAll() {
		return refeicaoRepository.findAll();
	}

	// Buscar refeição por ID
	public Refeicao findById(Integer id) {
		return refeicaoRepository.findById(id).orElse(null);
	}

	// Salvar nova refeição
	@Transactional
	public Refeicao save(Refeicao refeicao, Integer cardapioId) {
		// Verificar se o cardápio existe
		Cardapio cardapio = cardapioRepository.findById(cardapioId)
				.orElseThrow(() -> new IllegalArgumentException("Cardápio não encontrado com ID: " + cardapioId));

		// Associar a refeição ao cardápio
		refeicao.setCardapio(cardapio);

		// Salvar a refeição
		return refeicaoRepository.save(refeicao);
	}

	// Atualizar refeição
	@Transactional
	public Refeicao update(Integer id, Refeicao refeicaoDetails) {
		// Buscar refeição existente
		Refeicao refeicao = refeicaoRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Refeição não encontrada com ID: " + id));

		// Atualizar os campos da refeição
		refeicao.setTipoRefeicao(refeicaoDetails.getTipoRefeicao());
		refeicao.setOpcao1(refeicaoDetails.getOpcao1());
		refeicao.setOpcao2(refeicaoDetails.getOpcao2());
		refeicao.setOpcao3(refeicaoDetails.getOpcao3());

		// Salvar alterações
		return refeicaoRepository.save(refeicao);
	}

	// Excluir refeição
	@Transactional
	public void delete(Integer id) {
		// Verificar se a refeição existe antes de excluir
		Refeicao refeicao = refeicaoRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Refeição não encontrada com ID: " + id));

		// Excluir a refeição
		refeicaoRepository.delete(refeicao);
	}

	// Listar refeições de um cardápio específico
	public List<Refeicao> findByCardapioId(Integer cardapioId) {
		// Verificar se o cardápio existe
		if (!cardapioRepository.existsById(cardapioId)) {
			throw new IllegalArgumentException("Cardápio não encontrado com ID: " + cardapioId);
		}

		// Retornar todas as refeições associadas ao cardápio
		
		return (List<Refeicao>) refeicaoRepository.findById(cardapioId).orElse(null);
	}
}
