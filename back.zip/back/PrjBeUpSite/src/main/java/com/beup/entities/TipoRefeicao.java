package com.beup.entities;

public enum TipoRefeicao {
	 CAFE_DA_MANHA,
	    ALMOCO,
	    JANTAR

}
