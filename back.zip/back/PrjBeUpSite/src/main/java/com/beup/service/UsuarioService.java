package com.beup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.beup.entities.Usuario;
import com.beup.repositories.UsuarioRepository;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Retorna todos os usuários
    public List<Usuario> getAllUsuarios() {
        return usuarioRepository.findAll();
    }

    // Retorna um usuário pelo ID
    public Usuario getUsuarioById(Integer id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    // Cria um novo usuário
    public Usuario createUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    // Atualiza um usuário existente
    public Usuario updateUsuario(Integer id, Usuario usuarioDetails) {
        Usuario usuario = usuarioRepository.findById(id).orElse(null);

        if (usuario != null) {
            usuario.setNomeUsuario(usuarioDetails.getNomeUsuario());
            usuario.setSobrenomeUsuario(usuarioDetails.getSobrenomeUsuario());
            usuario.setCpfUsuario(usuarioDetails.getCpfUsuario());
            usuario.setEmailUsuario(usuarioDetails.getEmailUsuario());
            usuario.setIdadeUsuario(usuarioDetails.getIdadeUsuario());
            usuario.setPesoUsuario(usuarioDetails.getPesoUsuario());
            usuario.setAlturaUsuario(usuarioDetails.getAlturaUsuario());
            usuario.setTelefoneUsuario(usuarioDetails.getTelefoneUsuario());
            return usuarioRepository.save(usuario);
        }
        return null;
    }

    // Remove um usuário pelo ID
    public void deleteUsuario(Integer id) {
        usuarioRepository.deleteById(id);
    }
}

