package com.beup.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.beup.entities.Refeicao;

public interface RefeicaoRepository extends JpaRepository<Refeicao, Integer>{

}
