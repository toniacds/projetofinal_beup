package com.beup.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Nutricionista")
public class Nutricionista {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idNutricionista;

	@Column(name = "nomeNutri", length = 100)
	private String nomeNutri;

	@Column(name = "crn", length = 45)
	private String crn;

	@Column(name = "emailNutri", length = 45)
	private String emailNutri;

	public Integer getIdNutricionista() {
		return idNutricionista;
	}

	public void setIdNutricionista(Integer idNutricionista) {
		this.idNutricionista = idNutricionista;
	}

	public String getNomeNutri() {
		return nomeNutri;
	}

	public void setNomeNutri(String nomeNutri) {
		this.nomeNutri = nomeNutri;
	}

	public String getCrn() {
		return crn;
	}

	public void setCrn(String crn) {
		this.crn = crn;
	}

	public String getEmailNutri() {
		return emailNutri;
	}

	public void setEmailNutri(String emailNutri) {
		this.emailNutri = emailNutri;
	}

}
