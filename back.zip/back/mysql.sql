create database mydb;
use mydb;

INSERT INTO nutricionista (crn, email_nutri, nome_nutri)
VALUES 
('12345', 'nutri1@email.com', 'Nutricionista Silva'),
('12346', 'nutri2@email.com', 'Nutricionista Souza'),
('12347', 'nutri3@email.com', 'Nutricionista Almeida'),
('12348', 'nutri4@email.com', 'Nutricionista Costa'),
('12349', 'nutri5@email.com', 'Nutricionista Pereira');

INSERT INTO usuario (altura_usuario, cpf_usuario, email_usuario, idade_usuario, nome_usuario, peso_usuario, sobrenome_usuario, telefone_usuario)
VALUES
('1.75', '123.456.789-01', 'usuario1@email.com', 30, 'João', 75.50, 'Silva', '123456789'),
('1.80', '123.456.789-02', 'usuario2@email.com', 28, 'Maria', 65.00, 'Oliveira', '987654321'),
('1.65', '123.456.789-03', 'usuario3@email.com', 35, 'Carlos', 80.00, 'Costa', '456789123'),
('1.70', '123.456.789-04', 'usuario4@email.com', 25, 'Ana', 70.00, 'Souza', '654123789'),
('1.78', '123.456.789-05', 'usuario5@email.com', 22, 'Pedro', 72.50, 'Almeida', '321654987');

INSERT INTO refeicao (opcao1, opcao2, opcao3, tipo_refeicao)
VALUES
('Pão integral', 'Café preto', 'Frutas', 'CAFE_DA_MANHA'),
('Ovos mexidos', 'Suco de laranja', 'Cereal', 'CAFE_DA_MANHA'),
('Arroz integral', 'Feijão', 'Carne grelhada', 'ALMOCO'),
('Peito de frango', 'Batata doce', 'Salada', 'ALMOCO'),
('Peixe assado', 'Arroz', 'Salada', 'JANTAR');

INSERT INTO cardapio (id_nutricionista, id_refeicao, id_usuario)
VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(4, 4, 4),
(5, 5, 5);


select * from usuario;
select * from refeicao;
select* from cardapio where id_usuario = 1;

SELECT 
    r.opcao1, r.opcao2, r.opcao3, r.tipo_refeicao, 
    n.nome_nutri
FROM 
    cardapio c
JOIN 
    refeicao r ON c.id_refeicao = r.id_refeicao
JOIN 
    nutricionista n ON c.id_nutricionista = n.id_nutricionista
JOIN 
    usuario u ON c.id_usuario = u.idusuario
WHERE 
    u.idusuario = 1;

use mydb

select * from cardapio;tipo_refeicao
select * from refeicao;

SHOW INDEX FROM cardapio;

ALTER TABLE cardapio
ADD PRIMARY KEY (id);

CREATE INDEX idx_cardapio_id ON cardapio(id);




