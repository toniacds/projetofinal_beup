package com.beup.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.beup.entities.Refeicao;
import com.beup.service.RefeicaoService;

@RestController
@RequestMapping("/refeicoes")
public class RefeicaoController {

	@Autowired
	private RefeicaoService refeicaoService;

	// Listar todas as refeições
	@GetMapping
	public ResponseEntity<List<Refeicao>> findAll() {
		List<Refeicao> refeicoes = refeicaoService.findAll();
		return ResponseEntity.ok(refeicoes);
	}

	// Buscar refeição por ID
	@GetMapping("/{id}")
	public ResponseEntity<Refeicao> findById(@PathVariable Integer id) {
		Refeicao refeicao = refeicaoService.findById(id);
		return refeicao != null ? ResponseEntity.ok(refeicao) : ResponseEntity.notFound().build();
	}

	// Salvar refeição associada a um cardápio
	@PostMapping("/{cardapioId}")
	public ResponseEntity<Refeicao> save(@PathVariable Integer cardapioId, @RequestBody Refeicao refeicao) {
		try {
			Refeicao refeicaoSalva = refeicaoService.save(refeicao, cardapioId);
			return ResponseEntity.ok(refeicaoSalva);
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(null);
		}
	}

	// Atualizar refeição por ID
	@PutMapping("/{id}")
	public ResponseEntity<Refeicao> update(@PathVariable Integer id, @RequestBody Refeicao refeicao) {
		try {
			Refeicao refeicaoAtualizada = refeicaoService.update(id, refeicao);
			return refeicaoAtualizada != null ? ResponseEntity.ok(refeicaoAtualizada)
					: ResponseEntity.notFound().build();
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(null);
		}
	}

	// Deletar refeição por ID
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> delete(@PathVariable Integer id) {
		try {
			refeicaoService.delete(id);
			return ResponseEntity.noContent().build();
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().build();
		}
	}

	// Listar refeições de um cardápio específico
	@GetMapping("/cardapio/{cardapioId}")
	public ResponseEntity<List<Refeicao>> findByCardapioId(@PathVariable Integer cardapioId) {
		try {
			List<Refeicao> refeicoes = refeicaoService.findByCardapioId(cardapioId);
			return ResponseEntity.ok(refeicoes);
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(null);
		}
	}
}
