package com.beup.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.beup.entities.Nutricionista;
import com.beup.repositories.NutricionistaRepository;

@RestController
@RequestMapping("/nutricionistas")
public class NutricionistaController {
	
	 @Autowired
	    private NutricionistaRepository nutricionistaRepository;

	    @GetMapping
	    public List<Nutricionista> getAllNutricionistas() {
	        return nutricionistaRepository.findAll();
	    }

	    @GetMapping("/{id}")
	    public Nutricionista getNutricionistaById(@PathVariable Integer id) {
	        return nutricionistaRepository.findById(id).orElse(null);
	    }

	    @PostMapping
	    public Nutricionista createNutricionista(@RequestBody Nutricionista nutricionista) {
	        return nutricionistaRepository.save(nutricionista);
	    }

	    @PutMapping("/{id}")
	    public Nutricionista updateNutricionista(@PathVariable Integer id, @RequestBody Nutricionista nutricionistaDetails) {
	        Nutricionista nutricionista = nutricionistaRepository.findById(id).orElse(null);
	        if (nutricionista != null) {
	            nutricionista.setNomeNutri(nutricionistaDetails.getNomeNutri());
	            nutricionista.setCrn(nutricionistaDetails.getCrn());
	            nutricionista.setEmailNutri(nutricionistaDetails.getEmailNutri());
	            return nutricionistaRepository.save(nutricionista);
	        }
	        return null;
	    }

	    @DeleteMapping("/{id}")
	    public void deleteNutricionista(@PathVariable Integer id) {
	        nutricionistaRepository.deleteById(id);
	    }
	}
