let currentQuestion = 1; 
let totalQuestions = 10;