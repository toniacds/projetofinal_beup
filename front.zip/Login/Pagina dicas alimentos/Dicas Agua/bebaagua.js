// Adiciona interatividade ao menu hambúrguer (se necessário)
document.addEventListener("DOMContentLoaded", function() {
    // Espera até que todo o conteúdo da página seja carregado antes de executar o código
    const check = document.getElementById("check"); // Seleciona o checkbox invisível que controla o menu
    const barra = document.querySelector(".barra"); // Seleciona o menu lateral (barra)

    // Adiciona um ouvinte de evento no checkbox para verificar mudanças em seu estado (marcado/desmarcado)
    check.addEventListener("change", function() {
        // Verifica se o checkbox foi marcado (menu aberto) ou desmarcado (menu fechado)
        if (check.checked) {
            // Se o checkbox estiver marcado, move a barra (menu lateral) para a posição visível
            barra.style.transform = "translateX(0)"; // A barra desliza para a posição inicial
        } else {
            // Se o checkbox estiver desmarcado, move a barra para fora da tela (oculta o menu)
            barra.style.transform = "translateX(-250px)"; // A barra desliza para a esquerda (fora da tela)
        }
    });
});
