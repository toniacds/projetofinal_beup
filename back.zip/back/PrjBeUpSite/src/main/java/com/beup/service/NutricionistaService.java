package com.beup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.beup.entities.Nutricionista;
import com.beup.repositories.NutricionistaRepository;


@Service
public class NutricionistaService {

    @Autowired
    private NutricionistaRepository nutricionistaRepository;

    public List<Nutricionista> findAll() {
        return nutricionistaRepository.findAll();
    }

    public Nutricionista findById(Integer id) {
        return nutricionistaRepository.findById(id).orElse(null);
    }

    public Nutricionista save(Nutricionista nutricionista) {
        return nutricionistaRepository.save(nutricionista);
    }

    public Nutricionista update(Integer id, Nutricionista nutricionistaDetails) {
        Nutricionista nutricionista = nutricionistaRepository.findById(id).orElse(null);
        if (nutricionista != null) {
            nutricionista.setNomeNutri(nutricionistaDetails.getNomeNutri());
            nutricionista.setCrn(nutricionistaDetails.getCrn());
            nutricionista.setEmailNutri(nutricionistaDetails.getEmailNutri());
            return nutricionistaRepository.save(nutricionista);
        }
        return null;
    }

    public void delete(Integer id) {
        nutricionistaRepository.deleteById(id);
    }
}
