package com.beup.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.beup.entities.Cardapio;
import com.beup.service.CardapioService;

@RestController
@RequestMapping("/cardapios")
public class CardapioController {

	@Autowired
	private CardapioService cardapioService;

	@PostMapping
	public ResponseEntity<Cardapio> createCardapio(@RequestBody Cardapio cardapio) {
		try {
			Cardapio cardapioSalvo = cardapioService.save(cardapio);
			return ResponseEntity.ok(cardapioSalvo);
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(null);
		}
	}

	@GetMapping
	public ResponseEntity<List<Cardapio>> findAllCardapios() {
		List<Cardapio> cardapios = cardapioService.findAll();
		return ResponseEntity.ok(cardapios);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Cardapio> findCardapioById(@PathVariable Integer id) {
		try {
			Cardapio cardapio = cardapioService.findById(id);
			return ResponseEntity.ok(cardapio);
		} catch (IllegalArgumentException e) {
			return ResponseEntity.notFound().build();
		}
	}
	 @GetMapping("/usuario/{idUsuario}")
	    public ResponseEntity<List<Cardapio>> findCardapiosByUsuarioId(@PathVariable Integer idUsuario) {
	        List<Cardapio> cardapios = cardapioService.findByUsuarioId(idUsuario);
	        return ResponseEntity.ok(cardapios);
	    }
	
	

}
