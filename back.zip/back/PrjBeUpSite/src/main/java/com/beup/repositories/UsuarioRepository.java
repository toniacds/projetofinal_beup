package com.beup.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.beup.entities.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {}
