package com.beup.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.beup.entities.Cardapio;

public interface CardapioRepository extends JpaRepository<Cardapio, Integer> {
	List<Cardapio> findByUsuario_Idusuario(Integer idusuario);
}
