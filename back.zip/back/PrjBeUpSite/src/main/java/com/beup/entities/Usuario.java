package com.beup.entities;

import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.math.BigDecimal;
@Entity
@Table(name = "Usuario")
public class Usuario {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer idusuario;

	    @Column(name = "nomeUsuario", length = 100)
	    private String nomeUsuario;

	    @Column(name = "sobrenomeUsuario", length = 100)
	    private String sobrenomeUsuario;

	    @Column(name = "cpfUsuario", length = 100)
	    private String cpfUsuario;

	    @Column(name = "emailUsuario", length = 45)
	    private String emailUsuario;

	    @Column(name = "idadeUsuario")
	    private Integer idadeUsuario;

	    @Column(name = "pesoUsuario", precision = 4, scale = 2)
	    private BigDecimal pesoUsuario;

	    @Column(name = "alturaUsuario", length = 45)
	    private String alturaUsuario;

	    @Column(name = "telefoneUsuario", length = 45)
	    private String telefoneUsuario;
	   

		public Integer getIdusuario() {
			return idusuario;
		}

		public void setIdusuario(Integer idusuario) {
			this.idusuario = idusuario;
		}

		public String getNomeUsuario() {
			return nomeUsuario;
		}

		public void setNomeUsuario(String nomeUsuario) {
			this.nomeUsuario = nomeUsuario;
		}

		public String getSobrenomeUsuario() {
			return sobrenomeUsuario;
		}

		public void setSobrenomeUsuario(String sobrenomeUsuario) {
			this.sobrenomeUsuario = sobrenomeUsuario;
		}

		public String getCpfUsuario() {
			return cpfUsuario;
		}

		public void setCpfUsuario(String cpfUsuario) {
			this.cpfUsuario = cpfUsuario;
		}

		public String getEmailUsuario() {
			return emailUsuario;
		}

		public void setEmailUsuario(String emailUsuario) {
			this.emailUsuario = emailUsuario;
		}

		public Integer getIdadeUsuario() {
			return idadeUsuario;
		}

		public void setIdadeUsuario(Integer idadeUsuario) {
			this.idadeUsuario = idadeUsuario;
		}

		public BigDecimal getPesoUsuario() {
			return pesoUsuario;
		}

		public void setPesoUsuario(BigDecimal pesoUsuario) {
			this.pesoUsuario = pesoUsuario;
		}

		public String getAlturaUsuario() {
			return alturaUsuario;
		}

		public void setAlturaUsuario(String alturaUsuario) {
			this.alturaUsuario = alturaUsuario;
		}

		public String getTelefoneUsuario() {
			return telefoneUsuario;
		}

		public void setTelefoneUsuario(String telefoneUsuario) {
			this.telefoneUsuario = telefoneUsuario;
		}
		
	    

}
