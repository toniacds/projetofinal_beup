package com.beup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjBeUpSiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
