package com.beup.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.beup.entities.Usuario;
import com.beup.repositories.UsuarioRepository;


@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
	
	 @Autowired
	    private UsuarioRepository usuarioRepository;

	    @GetMapping
	    public List<Usuario> getAllUsuarios() {
	        return usuarioRepository.findAll();
	    }

	    @GetMapping("/{id}")
	    public Usuario getUsuarioById(@PathVariable Integer id) {
	        return usuarioRepository.findById(id).orElse(null);
	    }

	    @PostMapping
	    public Usuario createUsuario(@RequestBody Usuario usuario) {
	        return usuarioRepository.save(usuario);
	    }

	    @PutMapping("/{id}")
	    public Usuario updateUsuario(@PathVariable Integer id, @RequestBody Usuario usuarioDetails) {
	        Usuario usuario = usuarioRepository.findById(id).orElse(null);
	        if (usuario != null) {
	            usuario.setNomeUsuario(usuarioDetails.getNomeUsuario());
	            usuario.setSobrenomeUsuario(usuarioDetails.getSobrenomeUsuario());
	            usuario.setCpfUsuario(usuarioDetails.getCpfUsuario());
	            usuario.setEmailUsuario(usuarioDetails.getEmailUsuario());
	            usuario.setIdadeUsuario(usuarioDetails.getIdadeUsuario());
	            usuario.setPesoUsuario(usuarioDetails.getPesoUsuario());
	            usuario.setAlturaUsuario(usuarioDetails.getAlturaUsuario());
	            usuario.setTelefoneUsuario(usuarioDetails.getTelefoneUsuario());
	            return usuarioRepository.save(usuario);
	        }
	        return null;
	    }

	    @DeleteMapping("/{id}")
	    public void deleteUsuario(@PathVariable Integer id) {
	        usuarioRepository.deleteById(id);
	    }

}
