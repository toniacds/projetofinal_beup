package com.beup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.beup.entities.Cardapio;
import com.beup.entities.Refeicao;
import com.beup.repositories.CardapioRepository;
import com.beup.repositories.NutricionistaRepository;
import com.beup.repositories.RefeicaoRepository;
import com.beup.repositories.UsuarioRepository;

@Service
public class CardapioService {

	@Autowired
	private CardapioRepository cardapioRepository;

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private NutricionistaRepository nutricionistaRepository;

	@Autowired
	private RefeicaoRepository refeicaoRepository;
	

    public List<Cardapio> findByUsuarioId(Integer idUsuario) {
        return cardapioRepository.findByUsuario_Idusuario(idUsuario);
    }

	// Listar todos os cardápios com informações detalhadas
	public List<Cardapio> findAll() {
		return cardapioRepository.findAll();
	}

	// Buscar um cardápio por ID com informações detalhadas
	public Cardapio findById(Integer id) {
		return cardapioRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Cardápio não encontrado."));
	}

	/*
	 * 
	 * @Transactional public Cardapio save(Cardapio cardapio) { // Validar e
	 * associar o usuário if (cardapio.getUsuario() == null ||
	 * cardapio.getUsuario().getIdusuario() == null) { throw new
	 * IllegalArgumentException("Usuário é obrigatório e deve ter um ID válido."); }
	 * cardapio.setUsuario(usuarioRepository.findById(cardapio.getUsuario().
	 * getIdusuario()) .orElseThrow(() -> new
	 * IllegalArgumentException("Usuário não encontrado.")));
	 * 
	 * // Validar e associar o nutricionista if (cardapio.getNutricionista() == null
	 * || cardapio.getNutricionista().getIdNutricionista() == null) { throw new
	 * IllegalArgumentException("Nutricionista é obrigatório e deve ter um ID válido."
	 * ); } cardapio.setNutricionista(nutricionistaRepository.findById(cardapio.
	 * getNutricionista().getIdNutricionista()) .orElseThrow(() -> new
	 * IllegalArgumentException("Nutricionista não encontrado.")));
	 * 
	 * // Salvar o cardápio primeiro (sem refeições) Cardapio cardapioSalvo =
	 * cardapioRepository.save(cardapio);
	 * 
	 * // Validar e salvar cada refeição associada if (cardapio.getRefeicoes() !=
	 * null && !cardapio.getRefeicoes().isEmpty()) { for (Refeicao refeicao :
	 * cardapio.getRefeicoes()) { refeicao.setCardapio(cardapioSalvo); // Vincular
	 * ao cardápio salvo refeicaoRepository.save(refeicao); // Salvar a refeição } }
	 * 
	 * // Retornar o cardápio com as refeições já salvas return
	 * cardapioRepository.findById(cardapioSalvo.getId()) .orElseThrow(() -> new
	 * IllegalArgumentException("Erro ao buscar cardápio salvo.")); }
	 */
	@Transactional
	public Cardapio save(Cardapio cardapio) {
		// Validar e associar o usuário
		if (cardapio.getUsuario() == null || cardapio.getUsuario().getIdusuario() == null) {
			throw new IllegalArgumentException("Usuário é obrigatório e deve ter um ID válido.");
		}
		cardapio.setUsuario(usuarioRepository.findById(cardapio.getUsuario().getIdusuario())
				.orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado.")));

		// Validar e associar o nutricionista
		if (cardapio.getNutricionista() == null || cardapio.getNutricionista().getIdNutricionista() == null) {
			throw new IllegalArgumentException("Nutricionista é obrigatório e deve ter um ID válido.");
		}
		cardapio.setNutricionista(nutricionistaRepository.findById(cardapio.getNutricionista().getIdNutricionista())
				.orElseThrow(() -> new IllegalArgumentException("Nutricionista não encontrado.")));

		// Salvar o cardápio primeiro (sem refeições)
		Cardapio cardapioSalvo = cardapioRepository.save(cardapio);

		// Validar e salvar cada refeição associada
		if (cardapio.getRefeicoes() != null && !cardapio.getRefeicoes().isEmpty()) {
			for (Refeicao refeicao : cardapio.getRefeicoes()) {
				refeicao.setCardapio(cardapioSalvo); // Vincular ao cardápio salvo
				refeicaoRepository.save(refeicao); // Salvar a refeição
			}
		}

		// Retornar o cardápio com as refeições já salvas
		return cardapioRepository.findById(cardapioSalvo.getId())
				.orElseThrow(() -> new IllegalArgumentException("Erro ao buscar cardápio salvo."));
	}

}
